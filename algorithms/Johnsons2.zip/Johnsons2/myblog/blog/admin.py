# blog/admin.py
from django.contrib import admin
# from .models import Post, Engineer
from .models import Engineer


# admin.site.register(Post)
admin.site.register(Engineer)
